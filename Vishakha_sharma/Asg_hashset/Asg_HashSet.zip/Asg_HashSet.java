import java.util.*;
 
class Test
{
    public static void main(String[]args)
    {
        HashSet<String> hs = new HashSet<String>();
 
        
        hs.add("Vishakha");
        hs.add("Vijay");
        hs.add("Yatharth");
        hs.add("Rekha");
 
     
        System.out.println(hs);
        System.out.println("Whether List contains Vishakha:" +
                           hs.contains("Vishakha"));
 
        
        hs.remove("Yatharth");
        System.out.println("After removing yatharth-"+hs);
 
        // Iterating over hash set items
        System.out.println("Iterating over list:");
        Iterator<String> i = hs.iterator();
        while (i.hasNext())
            System.out.println(i.next());
    }
}