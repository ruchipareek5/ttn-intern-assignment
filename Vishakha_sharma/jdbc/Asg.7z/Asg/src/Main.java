
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.*;
import java.util.*;

public class Main {



    public static void main(String[] args) {
        Connection con = null;

        try {
            Class.forName("com.mysql.jdbc.Driver");
        }

        catch (ClassNotFoundException e) {
            e.printStackTrace();
        }



        try {
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/trig","root","root");




            CallableStatement c = con.prepareCall("call insert_data('vishakha','22','Female')");
            CallableStatement c1 = con.prepareCall("call insert_data('yatharth','20','Male')");
            CallableStatement c2 = con.prepareCall("call insert_data('Neha','18','Female')");



//executing
            c.execute();
            c1.execute();
            c2.execute();




            // PreparedStatement
            String preparedQuery = "SELECT * FROM details  ;";

            PreparedStatement st = con.prepareStatement(preparedQuery);


            ResultSet rs = st.executeQuery();
            HashMap<String,ArrayList> hm= new HashMap<>();


            while (rs.next())
            {ArrayList<String> al =new ArrayList();

                hm.put(rs.getString("username"),al);
                al.add(rs.getString("age"));




            }

            hm.forEach((x,y)-> {
                System.out.println(x);
                y.forEach(z-> System.out.println(z));

            });



        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
