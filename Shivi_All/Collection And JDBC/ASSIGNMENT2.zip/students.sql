create database students;
use  students;
create table StudentDetails(S_id int primary key not null, S_name varchar(50), S_Course varchar(50), S_percentage int);
insert into StudentDetails values(01, 'Aakash', 'B.Tech', 90);
insert into StudentDetails values(02, 'Shivangi', 'MCA', 80);
insert into StudentDetails values(03, 'Sakshi', 'MCA', 75);
insert into StudentDetails values(04, 'Sukirti', 'BA', 60);
insert into StudentDetails values(05, 'Karishma', 'MA', 50);
insert into StudentDetails values(06, 'Rajat', 'BJMC', 60);
insert into StudentDetails values(07, 'Akshita', 'MBBS', 78);

