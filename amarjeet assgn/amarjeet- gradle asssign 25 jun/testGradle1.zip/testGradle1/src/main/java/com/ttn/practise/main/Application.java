package com.ttn.practise.main;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

//import java.sql.SQLException;
import java.sql.Statement;


public class Application {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		try{  
			//Class.forName("com.mysql.jdbc.Driver");  
			Connection con=DriverManager.getConnection(  
			"jdbc:mysql://localhost:3306/ttn_test_gradle","root","root"); 
			 String query = " insert into ttn_user (uid, uname, age)"+ " values (?, ?, ?)";

		     PreparedStatement preparedStmt = (PreparedStatement) con.prepareStatement(query);
			 preparedStmt.setInt (1, 102);
			 preparedStmt.setString (2, "Amarjeet");
             preparedStmt.setInt (3, 23);
     		 preparedStmt.execute();
			Statement stmt=(Statement) con.createStatement();  
			ResultSet rs=stmt.executeQuery("select * from ttn_user");  
			while(rs.next())  
			System.out.println(rs.getInt(1)+"  "+rs.getString(2)+"  "+rs.getInt(3));  
			con.close();  
			}
		    catch(Exception e)
		     {
				System.out.println(e);
			}  


		
	}

}
