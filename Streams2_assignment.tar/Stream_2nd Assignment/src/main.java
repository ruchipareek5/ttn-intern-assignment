import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class main {
    public static void main(String[] args) {


        trainingPartnerBatchDetails tpd1 = new trainingPartnerBatchDetails(1, "Solar", new Date(118, 01, 01),
                new Date(118, 9, 01), 30, false);

        trainingPartnerBatchDetails tpd2 = new trainingPartnerBatchDetails(2, "Waste Picker", new Date(118, 02, 02),
                new Date(118, 10, 02), 40, false);

        trainingPartnerBatchDetails tpd3 = new trainingPartnerBatchDetails(3, "Solar PV", new Date(117, 02, 02),
                new Date(117, 03, 02), 25, true);

        trainingPartnerBatchDetails tpd4 = new trainingPartnerBatchDetails(4, "Water Management", new Date(118, 04, 02),
                new Date(118, 06, 02), 20, false);

        trainingPartnerBatchDetails tpd5 = new trainingPartnerBatchDetails(5, "Solar Installer", new Date(118, 04, 02),
                new Date(118, 05, 02), 60, true);


        trainingPartnerBatchDetails tpd6 = new trainingPartnerBatchDetails(6, "Solar", new Date(116, 01, 01),
                new Date(116, 02, 01), 10, true);

        trainingPartnerBatchDetails tpd7 = new trainingPartnerBatchDetails(7, "Waste Picker", new Date(116, 02, 02),
                new Date(116, 03, 02), 15, true);

        trainingPartnerBatchDetails tpd8 = new trainingPartnerBatchDetails(8, "Solar PV", new Date(116, 02, 02),
                new Date(116, 03, 02), 25, true);

        trainingPartnerBatchDetails tpd9 = new trainingPartnerBatchDetails(9, "Water Management", new Date(116, 04, 02),
                new Date(116, 06, 02), 50, true);

        trainingPartnerBatchDetails tpd10 = new trainingPartnerBatchDetails(10, "Solar Installer", new Date(116, 04, 02),
                new Date(116, 05, 02), 60, true);

        ArrayList<trainingPartnerBatchDetails> b = new ArrayList<trainingPartnerBatchDetails>();

        b.add(tpd1);
        b.add(tpd2);
        b.add(tpd3);
        b.add(tpd4);
        b.add(tpd5);
        b.add(tpd6);
        b.add(tpd7);
        b.add(tpd8);
        b.add(tpd9);
        b.add(tpd10);
//        System.out.println(new Date());
//        System.out.println(tpd1.getEndDate());
//        System.out.println(tpd1.getEndDate().compareTo(new Date()));



        Stream<trainingPartnerBatchDetails> forFiletering = b.stream();
      List<trainingPartnerBatchDetails> pastBatches= forFiletering.filter(endDate -> (endDate.getEndDate().compareTo(new Date(118,1,1)))<0).collect(Collectors.toList());


      HashMap<String,List<trainingPartnerBatchDetails>>batchMap =new HashMap<>();

        batchMap.put("past batches",pastBatches);
       // batchMap.put("present batches",presentBatches);

        batchMap.forEach((x,y)->{

            System.out.println(x);

            y.forEach(z->{
                System.out.println(z);
            });
        });

        Stream<trainingPartnerBatchDetails> forFiletering1 = b.stream();
        List<trainingPartnerBatchDetails> presentBatches= forFiletering1.filter(endDate -> (endDate.getEndDate().compareTo(new Date(118,1,1)))>0).collect(Collectors.toList());
        //batchMap.put("past batches",pastBatches);
        batchMap.put("present batches",presentBatches);

        batchMap.forEach((x,y)->{

            System.out.println(x);

            y.forEach(z->{
                System.out.println(z);
            });
        });
        }


}
