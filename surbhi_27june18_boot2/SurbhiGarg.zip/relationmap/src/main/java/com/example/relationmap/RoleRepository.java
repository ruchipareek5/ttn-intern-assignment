package com.example.relationmap;

import org.springframework.data.jpa.repository.JpaRepository;

public interface RoleRepository  extends JpaRepository<RoleModel,Integer>{
	public RoleModel findByRoleId(int role_id);

}
