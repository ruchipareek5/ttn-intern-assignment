package com.example.relationmap;

import java.math.BigInteger;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

public interface UserRepository extends JpaRepository<UserModel,BigInteger> {
	public List<UserModel>findAll();

}
