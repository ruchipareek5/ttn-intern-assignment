import java.util.ArrayList;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.Vector;
import java.util.stream.Stream;

public class streamsDemoApp {


    public static void main(String[] args) {

        ArrayList<Person> listOfPerson = new ArrayList<>();

        Person p1 = new Person("Rishabh",20, Person.gender.Male);
        Person p2 = new Person("Lohit",21, Person.gender.Male);
        Person p3 = new Person("Gagan",22, Person.gender.Male);
        Person p4 = new Person("Shubham",23, Person.gender.Male);
        Person p5 = new Person("Vagish",21, Person.gender.Male);
        Person p6 = new Person("Prateek",22, Person.gender.Male);
        Person p7 = new Person("Surbhi",23, Person.gender.Female);
        Person p8 = new Person("Nishtha",24, Person.gender.Female);
        Person p9 = new Person("Rohit",20, Person.gender.Male);
        Person p10 = new Person("Ayushi",20, Person.gender.Female);

        listOfPerson.add(p1);
        listOfPerson.add(p2);
        listOfPerson.add(p3);
        listOfPerson.add(p4);
        listOfPerson.add(p5);
        listOfPerson.add(p6);
        listOfPerson.add(p7);
        listOfPerson.add(p8);
        listOfPerson.add(p9);
        listOfPerson.add(p10);

        Iterator<Person> i = listOfPerson.iterator();

        ArrayList<Person> femalePerson = new ArrayList<>();

        while(i.hasNext())
        {
            Person p = i.next();

          Person.gender s = p.getGen();
            if(s ==Person.gender.Female) {
                femalePerson.add(p);


            }

        }

        Stream<Person> streamForFilter = femalePerson.stream();
        streamForFilter.forEach(age-> age.setAge( age.getAge()-2));

        Iterator f = femalePerson.iterator();

        while (f.hasNext())
        {
          Person female  = (Person) f.next();

            System.out.println(female.getName() + " " +female.getAge());
        }




    }



    }

