public class Person {

    private  String name;
    private int age;
    enum gender {Male,Female,Other;}
    private gender gen;

    public Person(String name, int age, gender gen) {
        this.name = name;
        this.age = age;
        this.gen = gen;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public gender getGen() {
        return gen;
    }

    public void setGen(gender gen) {
        this.gen = gen;
    }
}
