create schema ques2;
use ques2;

create table offenders(
name varchar(20) unique,
id int primary key,
age int
);

create table violations(
code int primary key,
id int,
fine int
);

select * from offenders;
select * from violations;

select count(*) from offenders, violations where offenders.age between 18 and 25 and violations.fine>100 and offenders.id=violations.id;

select offenders.name,violations.id,violations.code from offenders, violations where offenders.age between 18 and 25 and violations.fine>100 and offenders.id=violations.id;