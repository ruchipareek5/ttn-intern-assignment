create schema ques8;
use ques8;

create table train(
trainid int primary key,
line varchar(10)
); 
drop table traininfo;

create table traininfo(
rowid int primary key,
trainid int,
foreign key(trainid) references train(trainid),
delay time,
coach int,
people int,
time varchar(10)
);

select * from train;
select * from traininfo;

select avg(delay) as avgdelay from traininfo group by trainid having time='6-8' and time='8-10';


