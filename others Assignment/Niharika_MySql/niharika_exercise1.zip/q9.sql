create schema ques9;
use ques9;

create table assignment(
aid int primary key,
startdate date,
enddate date,
location varchar(10)
);
drop table assignments;

create table emp(
empid int primary key,
empname varchar(50),
h1B boolean,
aid int,
foreign key(aid) references assignment(aid)
); 

select * from assignment;
select * from emp;

select emp.empid,emp.empname,emp.aid,assignment.enddate, assignment.startdate 
from emp,assignment 
where emp.h1B=1 and assignment.enddate>=curdate() and assignment.startdate!='2018-07-01' and emp.aid=assignment.aid;
