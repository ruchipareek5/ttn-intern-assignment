create schema ques5;
use ques5;

create table user(
uname varchar(10),
uid int primary key,
contact bigint,
address varchar(50),
workplace varchar(50)
);

create table passengers(
uid int,
rideno int primary key,
destinationaddress varchar(50),
foreign key(uid) references user(uid)
);

select * from user;
select * from passengers;

select uid as 'total' from passengers group by uid having count(rideno)=max(total) order by uid;

select passengers.uid, user.uname from user,passengers where user.workplace=passengers.destinationaddress;

select distinct passengers.uid, user.uname from user,passengers group by uid having count(rideno)>2 and passengers.uid=user.uid;