create schema ques6;
use ques6;

create table batch(
batchid int primary key,
byear year
);
 
create table student(
sid int primary key,
sname varchar(10),
batchid int,
eligible boolean,
participated boolean,
selected boolean,
foreign key(batchid) references batch(batchid)
);

select * from batch;
select * from student;

select student.sid, batch.byear from student,batch where student.eligible=1 and student.participated=1 and student.selected=0 and batch.batchid=student.batchid and byear>=year(curdate())-5;
select distinct student.sid, batch.byear from student,batch where student.eligible=1 and student.participated=0 and batch.batchid=student.batchid and byear>=year(curdate())-5;
select distinct student.sid, batch.byear from student,batch where student.eligible=0 and batch.batchid=student.batchid and byear>=year(curdate())-5;

