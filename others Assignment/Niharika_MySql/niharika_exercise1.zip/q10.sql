create schema ques10;
use ques10;

create table user(
uid int primary key,
uname varchar(50),
contact bigint
);

create table emp(
eid int primary key,
ename varchar(50)
);

create table transaction(
uid int,
eid int,
tstatus int,
tid int primary key,
foreign key(eid) references emp(eid),
foreign key(uid) references user(uid)
);

select * from user;
select * from transaction;
select * from emp;

select transaction.tid, transaction.eid from transaction,user where user.uname='nirav modi' and user.uid=transaction.uid;

select distinct tid,uid from transaction 
where uid
not in(select uid from user where uname='nirav modi');