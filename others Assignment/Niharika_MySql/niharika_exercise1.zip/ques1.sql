create schema ques1;
use ques1;

create table if not exists mall(
shopname varchar(50) not null,
shopid int primary key,
openingDate date
);

create table if not exists sales(
saleid int primary key,
shopid int not null,
month1 varchar(10),
month2 varchar(10),
month3 varchar(10),
month4 varchar(10),
month5 varchar(10),
month6 varchar(10),
foreign key(shopid) references mall(shopid)
);

select * from mall;
select * from sales;
select sales.shopid,mall.shopname from sales, mall where sales.month1+sales.month2+sales.month3+sales.month4+sales.month5+sales.month6>50 and mall.shopid=sales.shopid;

