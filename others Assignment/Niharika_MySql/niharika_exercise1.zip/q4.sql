create schema ques4;
use ques4;

create table states(
sname varchar(50),
sid int primary key,
carbonemission int,
plasticConsumption int,
energyUsage int
);

create table action(
