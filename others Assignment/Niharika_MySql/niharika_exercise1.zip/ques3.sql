create schema ques3;
use ques3;

create table students(
Sname varchar(50) unique,
rollno int(10) primary key,
fathersname varchar(50),
course varchar(10)
);
drop table students;

create table classes(
rollno int,
semester1 varchar(10),
semester2 varchar(10),
id int primary key
);

select * from students;
select * from classes;

select students.sname, students.rollno, students.fathersname, students.course from students where rollno in(select rollno from classes where semester1='notregular' and semester2='notregular');
