create schema ques7;
use ques7;

create table emp(
empid int primary key,
empname varchar(10),
pid int,
foreign key(pid) references project(pid)
);

create table project(
pid int primary key,
requiredemp int,
currentemp int,
startdate date,
enddate date
);

create table project_emp(
pid int,
empid int,
primary key(pid,empid),
foreign key(pid) references project(pid),
foreign key(empid) references emp(empid),
performance int
);

select * from project;
select * from emp;
select * from project_emp;

select * from emp where pid is null;
select pid from project where currentemp<requiredemp;

